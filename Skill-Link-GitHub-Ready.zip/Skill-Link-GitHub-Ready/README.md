# Skill Link

### A Platform to Bridge the Gap Between Skilled Manual Workers and Job Providers Using Smart Technologies

Skill Link is a web-based platform designed to connect skilled and semi-skilled workers with employers. The project focuses on making it easier for workers to create profiles, discover opportunities, and communicate with employers, while giving employers tools to post jobs, manage applications, find workers, and handle service bookings.

The project documentation also describes planned smart features such as AI/ML-based job recommendations, skill tagging, sentiment-based feedback analysis, multilingual/voice accessibility, real-time notifications, and chatbot assistance.

> **Project status:** This repository contains the actual project implementation supplied for the Skill Link project, together with selected public-facing project documentation and posters.

## Core Features in the Implementation

- Worker registration and profile management
- Employer registration and job management
- Job listings and applications
- Worker/employer dashboards
- Service listings and service bookings
- Booking confirmation and booking management
- Authentication and role-based authorization
- JWT-based authentication flow
- File upload middleware
- Messaging and real-time communication using Socket.IO
- MongoDB data models and persistence
- OTP-related backend functionality
- Error handling and request validation

## Technology Stack

### Frontend
- HTML5
- CSS3
- JavaScript

### Backend
- Node.js
- Express.js
- MongoDB
- Mongoose
- Socket.IO
- JWT
- Multer
- Express Validator

### Project Documentation
- System workflow and architecture material
- Project synopsis
- Project report
- Research paper
- Project posters

## Project Structure

```text
Skill-Link/
├── frontend/                 # Actual HTML, CSS and JavaScript frontend
├── backend/                  # Actual Node.js / Express backend
│   ├── config/
│   ├── controller/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   └── utils/
├── docs/                     # Selected project documentation
├── posters/                  # Selected project posters
├── .gitignore
└── README.md
```

## Backend Setup

1. Install Node.js.
2. Start MongoDB locally or use a MongoDB deployment.
3. Open a terminal in `backend/`.
4. Install dependencies:

```bash
npm install
```

5. Create a `.env` file from `.env.example` and enter your own credentials.
6. Start the development server:

```bash
npm run dev
```

The backend health endpoint is:

```text
http://localhost:3000/api/health
```

## Important: Environment Variables

The original project contained a `.env` file with private configuration. It has **not** been included in this GitHub-ready package.

Use:

```text
backend/.env.example
```

Never commit API keys, JWT secrets, database passwords, OTP/SMS credentials, or other private credentials to GitHub.

## Project Workflow

The project workflow described in the project poster is:

```text
Worker Registration
        ↓
Job Posting
        ↓
AI/ML Matching
        ↓
Real-time Notifications
        ↓
Chatbot Assistance
        ↓
Feedback & Ratings
        ↓
Skill Link Core Database
```

## Smart Technology Scope

The supplied project synopsis proposes the use of AI/ML for personalized job recommendations, skill tagging, and sentiment-based feedback systems. It also describes multilingual and voice-enabled accessibility and chatbot assistance as part of the project's intended smart-technology scope.

## Academic Team

The supplied project documentation lists:

- Mahesh Yemmewar
- Omkar Shakkarwar
- Rohit Shejul

Guided by Prof. Girish Patil, G H Raisoni College of Engineering and Management, Wagholi, Pune.

## Documentation

- `docs/Skill_Link_Synopsis.pdf`
- `docs/Final_Skill_Project_Report.pdf`
- `docs/Research_Paper.pdf`
- `posters/Skill_Link_Workflow_Poster.pdf`
- `posters/Skill_Link_Poster.pdf`
- `posters/Skill_Link_Poster_Visual.pdf`

## GitHub Publishing Checklist

Before making the repository public:

- [ ] Add screenshots of the running application
- [ ] Test the backend with your own MongoDB configuration
- [ ] Confirm no `.env` or API credentials are committed
- [ ] Add the repository URL to the resume/LinkedIn
- [ ] Update the README with the deployed demo URL if you deploy it

## License

The repository includes the project's existing license file where applicable. Review the license and any institutional/project ownership requirements before redistributing the project publicly.
