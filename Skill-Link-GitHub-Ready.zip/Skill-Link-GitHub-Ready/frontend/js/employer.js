const API_BASE = "http://localhost:4000/api";
const token = localStorage.getItem("token");
const storedUser = JSON.parse(localStorage.getItem("user") || "null");

if (!token || storedUser?.role !== "employer") {
  window.location.href = "login.html";
}

const els = {
  stats: {
    total: document.getElementById("statTotalJobs"),
    open: document.getElementById("statOpenJobs"),
    paused: document.getElementById("statPausedJobs"),
    applicants: document.getElementById("statApplicants"),
  },
  jobsContainer: document.getElementById("employerJobsContainer"),
  applicantsContainer: document.getElementById("recentApplicantsContainer"),
  jobForm: document.getElementById("jobForm"),
  refreshJobs: document.getElementById("refreshJobs"),
  refreshApplicants: document.getElementById("refreshApplicants"),
  employerName: document.getElementById("employerName"),
  employerRole: document.getElementById("employerRole"),
  employerId: document.getElementById("employerId"),
  employerGreeting: document.getElementById("employerGreeting"),
  avatar: document.getElementById("employerAvatar"),
  logoutButtons: [
    document.getElementById("logoutEmployer"),
    document.getElementById("mobileLogout"),
  ],
  newJobButtons: [
    document.getElementById("openJobFormButton"),
    document.getElementById("openJobFormSidebar"),
  ],
};

const headers = {
  Authorization: `Bearer ${token}`,
  "Content-Type": "application/json",
};

const currencyFormatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

function renderProfile(profile) {
  const name = profile?.name || `${storedUser.firstName} ${storedUser.lastName}`;
  els.employerName.textContent = name;
  els.employerGreeting.textContent = `Welcome back, ${name.split(" ")[0]} 👋`;
  els.employerRole.textContent = profile?.role || "employer";
  els.employerId.textContent = profile?.id || storedUser._id || storedUser.id;

  if (profile?.avatarUrl) {
    els.avatar.style.backgroundImage = `url(${profile.avatarUrl})`;
    els.avatar.style.backgroundSize = "cover";
    els.avatar.textContent = "";
  } else {
    const initials = name
      .split(" ")
      .map((chunk) => chunk[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();
    els.avatar.textContent = initials;
    els.avatar.style.backgroundImage = "";
  }
}

function renderStats(stats = {}) {
  els.stats.total.textContent = stats.totalJobs ?? 0;
  els.stats.open.textContent = stats.openJobs ?? 0;
  els.stats.paused.textContent = stats.pausedJobs ?? 0;
  els.stats.applicants.textContent = stats.applicants ?? 0;
}

function renderJobs(jobs = []) {
  if (!jobs.length) {
    els.jobsContainer.innerHTML =
      '<p class="text-sm text-ink-muted border border-dashed border-gray-200 rounded-2xl p-6 text-center">No jobs posted yet. Click "New job" to get started.</p>';
    return;
  }

  els.jobsContainer.innerHTML = jobs
    .map(
      (job) => `
      <article class="border border-gray-100 rounded-2xl p-5 grid gap-3 bg-white shadow-sm hover:shadow-md transition cursor-pointer" onclick="window.location.href='job-management.html?id=${job.id}'">
        <div class="flex items-start justify-between gap-4">
          <div>
            <p class="text-xs text-ink-muted uppercase tracking-wide">${job.location || "Flexible"}</p>
            <h4 class="text-lg font-semibold text-ink">${job.title}</h4>
          </div>
          <span class="px-3 py-1 rounded-full text-xs font-semibold ${
            job.status === "open"
              ? "bg-emerald-50 text-emerald-600"
              : job.status === "paused"
              ? "bg-amber-50 text-amber-600"
              : "bg-slate-100 text-slate-700"
          } capitalize">${job.status}</span>
        </div>
        <div class="flex flex-wrap gap-4 text-sm text-ink-muted">
          <span><strong class="text-ink">Budget:</strong> ${
            job.pay ? currencyFormatter.format(job.pay) : "N/A"
          }</span>
          <span><strong class="text-ink">Applicants:</strong> ${job.applicants}</span>
          <span><strong class="text-ink">Posted:</strong> ${new Date(job.createdAt).toLocaleDateString()}</span>
        </div>
        <div class="flex flex-wrap gap-2">
          <button
            onclick="event.stopPropagation(); window.location.href='job-management.html?id=${job.id}'"
            class="inline-flex items-center gap-1 text-sm text-primary font-semibold hover:text-primary/80"
          >
            <span class="material-symbols-outlined text-base">visibility</span>
            Manage
          </button>
          <button
            data-job="${job.id}"
            class="delete-job inline-flex items-center gap-1 text-sm text-rose-600 font-semibold hover:text-rose-700"
            onclick="event.stopPropagation()"
          >
            <span class="material-symbols-outlined text-base">delete</span>
            Remove
          </button>
        </div>
      </article>
    `
    )
    .join("");

  document.querySelectorAll(".delete-job").forEach((btn) =>
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const jobId = e.currentTarget.getAttribute("data-job");
      if (confirm("Delete this job?")) {
        deleteJob(jobId);
      }
    })
  );
}

function renderApplicants(applicants = []) {
  if (!applicants.length) {
    els.applicantsContainer.innerHTML =
      '<p class="text-sm text-ink-muted">Waiting for new applications...</p>';
    return;
  }

  els.applicantsContainer.innerHTML = applicants
    .map(
      (app) => `
        <div class="border border-gray-100 rounded-2xl p-4 bg-white shadow-sm hover:shadow-md transition cursor-pointer" onclick="window.location.href='applicant-detail.html?id=${app.id}'">
          <p class="text-sm font-semibold text-ink">${app.workerName}</p>
          <p class="text-xs text-ink-muted mb-1">${app.jobTitle}</p>
          <span class="px-2 py-0.5 rounded-full text-xs font-semibold ${
            app.status === "accepted"
              ? "bg-emerald-50 text-emerald-600"
              : app.status === "rejected"
              ? "bg-rose-50 text-rose-600"
              : "bg-amber-50 text-amber-600"
          }">${app.status}</span>
          <p class="text-xs text-ink-muted mt-2">${new Date(app.createdAt).toLocaleString()}</p>
          <button
            onclick="event.stopPropagation(); window.location.href='applicant-detail.html?id=${app.id}'"
            class="mt-3 w-full px-3 py-1.5 bg-primary text-white rounded-lg font-semibold hover:bg-primary/90 text-xs"
          >
            View Details
          </button>
        </div>
      `
    )
    .join("");
}

async function fetchDashboard() {
  els.jobsContainer.innerHTML =
    '<div class="animate-pulse rounded-2xl bg-white border border-gray-100 p-6"><div class="h-4 bg-gray-200 rounded w-1/2 mb-3"></div><div class="h-3 bg-gray-100 rounded w-1/3"></div></div>';

  try {
    const res = await fetch(`${API_BASE}/employer/dashboard`, { headers });
    if (!res.ok) throw new Error("Unable to load dashboard");
    const data = await res.json();

    renderProfile(data.profile);
    renderStats(data.stats);
    renderJobs(data.jobs);
    renderApplicants(data.recentApplicants);
  } catch (error) {
    console.error(error);
    els.jobsContainer.innerHTML = `<p class="text-rose-500">${error.message}</p>`;
  }
}

async function deleteJob(jobId) {
  try {
    const res = await fetch(`${API_BASE}/employer/jobs/${jobId}`, {
      method: "DELETE",
      headers,
    });
    if (!res.ok) throw new Error("Failed to delete job");
    fetchDashboard();
  } catch (error) {
    alert(error.message);
  }
}

els.jobForm?.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    title: document.getElementById("title").value.trim(),
    location: document.getElementById("location").value.trim(),
    pay: Number(document.getElementById("pay").value),
    description: document.getElementById("description").value.trim(),
    skills: document.getElementById("skills").value.trim(),
  };

  if (!payload.title || !payload.description) {
    alert("Title and description are required.");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/employer/jobs`, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error("Failed to create job");
    els.jobForm.reset();
    fetchDashboard();
  } catch (error) {
    alert(error.message);
  }
});

els.refreshJobs?.addEventListener("click", fetchDashboard);
els.refreshApplicants?.addEventListener("click", fetchDashboard);

els.logoutButtons
  .filter(Boolean)
  .forEach((btn) =>
    btn.addEventListener("click", () => {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location.href = "login.html";
    })
  );

els.newJobButtons
  .filter(Boolean)
  .forEach((btn) =>
    btn.addEventListener("click", () => {
      els.jobForm?.scrollIntoView({ behavior: "smooth", block: "center" });
      document.getElementById("title")?.focus();
    })
  );

fetchDashboard();
