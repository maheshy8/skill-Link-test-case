const API_BASE = "http://localhost:3000/api/auth"; // backend prefix

async function handleLogout() {
  try {
    const res = await fetch(`${API_BASE}/logout`, {
      method: "POST",
      credentials: "include"
    });

    if (res.ok) {
      localStorage.removeItem("user");
      alert("✅ Logged out");
      window.location.href = "login.html";
    }
  } catch (err) {
    console.error(err);
    alert("⚠️ Error logging out");
  }
}

function toggleLogoutVisibility(show) {
  document.querySelectorAll('[data-action="logout"]').forEach(btn => {
    btn.classList.toggle("hidden", !show);
  });
  document.querySelectorAll('[data-action="my-bookings"]').forEach(btn => {
    btn.classList.toggle("hidden", !show);
  });
}

function checkAuth() {
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const authStatus = document.getElementById("authStatus");

  if (user) {
    if (authStatus) {
      authStatus.textContent = `Welcome, ${user.role ?? "user"}`;
    }
    toggleLogoutVisibility(true);
  } else {
    if (authStatus) {
      authStatus.textContent = "Not logged in";
    }
    toggleLogoutVisibility(false);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll('[data-action="logout"]').forEach(btn => {
    btn.addEventListener("click", (event) => {
      event.preventDefault();
      handleLogout();
    });
  });
});

window.handleLogout = handleLogout;
window.checkAuth = checkAuth;